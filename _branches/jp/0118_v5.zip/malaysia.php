<?php
// Legacy entry point (kept for backward compatibility)
header('Location: country.php');
exit;
