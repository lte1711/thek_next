<h2>P / S - <?= t('title.settlement.partner_daily','Partner Daily Settlement') ?></h2>

<div style="margin:12px 0 18px;">
  <form method="GET" class="form-inline" style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
    <input type="hidden" name="region" value="<?= htmlspecialchars($region) ?>">

    <label style="font-weight:600;"><?= t('label.select_date','Select Date:') ?></label>
    <input type="text" class="js-date" name="partner_date" value="<?= htmlspecialchars($partner_date ?? '') ?>" autocomplete="off" inputmode="none" placeholder="YYYY-MM-DD" style="width:165px;">

    <button type="submit"><?= t('btn.search','Search') ?></button>

    <?php if (!empty($partner_is_settled)): ?>
      <button type="button" disabled style="opacity:0.6; cursor:not-allowed;"><?= t('btn.settled','Settled') ?></button>
      <span style="font-size:12px; opacity:0.8;">
        <?= !empty($partner_settled_at) ? "(" . t('partner.settlement.settled_at', 'Settled at') . ": " . htmlspecialchars($partner_settled_at) . ")" : "" ?>
      </span>
    <?php else: ?>
      <button type="button" onclick="confirmPartnerSettlement(event)"><?= t('btn.settle','Settle') ?></button>
    <?php endif; ?>
  </form>

  <table style="margin-top:12px;">
    <tr>
      <th><?= t('table.name','Name') ?></th>
      <th><?= t('table.total_revenue','Total Revenue') ?></th>
      <th style="color:#d33;">profit(20%)</th>
    </tr>

    <?php if (!empty($dividend_rows) && is_array($dividend_rows)): ?>
      <?php foreach ($dividend_rows as $row): ?>
        <?php
          // Name은 gm2_username을 기본으로 사용 (기존 화면: Zayne)
          $name = $row['gm2_username'] ?? 'Zayne';
          // 같은 날짜에 여러 건일 때 구분을 위해 시간 표기
          $time_suffix = '';
          if (!empty($row['tx_date'])) {
            $time_suffix = ' (' . date('H:i:s', strtotime($row['tx_date'])) . ')';
          }
          $row_total = (float)($row['row_total_revenue'] ?? 0);
          $row_profit20 = (float)($row['row_profit20'] ?? 0);
        ?>
        <tr>
          <td><?= htmlspecialchars($name . $time_suffix) ?></td>
          <td><?= number_format($row_total, 2) ?></td>
          <td><?= number_format($row_profit20, 2) ?></td>
        </tr>
      <?php endforeach; ?>

      <!-- ✅ Total 행: 각 열 합계 -->
      <tr>
        <td><strong><?= t('common.total','Total') ?></strong></td>
        <td><strong><?= number_format((float)($total_revenue_sum ?? 0), 2) ?></strong></td>
        <td><strong><?= number_format((float)($profit20_sum ?? 0), 2) ?></strong></td>
      </tr>
    <?php else: ?>
      <tr>
        <td colspan="3" style="text-align:center; padding:14px; opacity:0.7;">
          <?= t('msg.no_data_for_selected_date','No data for the selected date.') ?>
        </td>
      </tr>
    <?php endif; ?>

  </table>
</div>

<script>
function confirmPartnerSettlement(e) {
  if (e) e.preventDefault();
  const isSettled = <?= !empty($partner_is_settled) ? 'true' : 'false' ?>;
  if (isSettled) { alert(<?= json_encode(t('settlement.already_completed','Settlement already completed for this date.')) ?>); return; }
  if (!confirm(<?= json_encode(t('settlement.confirm_proceed','Proceed with settlement?')) ?>)) return;

  const settleDate = "<?= htmlspecialchars($partner_date ?? '') ?>";

  fetch('gm_settle_confirm.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'settle_date=' + encodeURIComponent(settleDate)
  })
  .then(async (res) => {
    const text = await res.text();
    if (!res.ok) throw new Error(text || 'Settlement failed');
    alert(text);
    location.reload();
  })
  .catch((err) => alert(err.message));
}
</script>

<script>
(function(){
  // language + labels from server (t())
  const LANG = <?= json_encode($_GET['lang'] ?? ($_SESSION['lang'] ?? 'ko')) ?>;
  const T = {
    today: <?= json_encode(t('common.today', 'Today')) ?>,
    clear: <?= json_encode(t('common.clear', 'Clear')) ?>,
    months: <?= json_encode([
      t('month.1','1'), t('month.2','2'), t('month.3','3'), t('month.4','4'),
      t('month.5','5'), t('month.6','6'), t('month.7','7'), t('month.8','8'),
      t('month.9','9'), t('month.10','10'), t('month.11','11'), t('month.12','12')
    ]) ?>,
    weekdays: <?= json_encode([
      t('weekday.sun','Sun'), t('weekday.mon','Mon'), t('weekday.tue','Tue'),
      t('weekday.wed','Wed'), t('weekday.thu','Thu'), t('weekday.fri','Fri'), t('weekday.sat','Sat')
    ]) ?>,
    yearSuffix: <?= json_encode(t('unit.year_suffix','')) ?>
  };

  function pad2(n){ return (n<10?'0':'')+n; }
  function fmtDate(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); }
  function fmtMonth(d){ return d.getFullYear()+'-'+pad2(d.getMonth()+1); }

  // single shared popup
  let popup = null;
  let activeInput = null;
  let mode = 'date'; // 'date' | 'month'
  let viewYear = null;
  let viewMonth = null;

  function ensurePopup(){
    if (popup) return popup;

    popup = document.createElement('div');
    popup.className = 'simple-picker';
    popup.style.cssText = [
      'position:absolute',
      'z-index:99999',
      'background:#fff',
      'border:1px solid rgba(0,0,0,0.12)',
      'border-radius:10px',
      'box-shadow:0 10px 30px rgba(0,0,0,0.15)',
      'padding:10px',
      'width:260px',
      'font-family:system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif',
      'user-select:none'
    ].join(';');

    popup.innerHTML = `
      <div class="sp-head" style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:8px;">
        <button type="button" class="sp-prev" style="border:none;background:#f2f4f7;border-radius:8px;padding:6px 10px;cursor:pointer;">‹</button>
        <div class="sp-title" style="font-weight:700; text-align:center; flex:1;"></div>
        <button type="button" class="sp-next" style="border:none;background:#f2f4f7;border-radius:8px;padding:6px 10px;cursor:pointer;">›</button>
      </div>
      <div class="sp-body"></div>
      <div class="sp-foot" style="display:flex; justify-content:space-between; gap:8px; margin-top:10px;">
        <button type="button" class="sp-clear" style="border:none;background:#fff;color:#555;cursor:pointer;">${T.clear}</button>
        <button type="button" class="sp-today" style="border:none;background:#2563eb;color:#fff;border-radius:8px;padding:6px 10px;cursor:pointer;">${T.today}</button>
      </div>
    `;

    document.body.appendChild(popup);

    // close on outside click / esc
    document.addEventListener('mousedown', (e) => {
      if (!popup || !activeInput) return;
      if (popup.contains(e.target) || e.target === activeInput) return;
      hide();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') hide();
    });

    popup.querySelector('.sp-prev').addEventListener('click', () => {
      if (mode === 'month') { viewYear -= 1; }
      else {
        viewMonth -= 1;
        if (viewMonth < 0) { viewMonth = 11; viewYear -= 1; }
      }
      render();
    });
    popup.querySelector('.sp-next').addEventListener('click', () => {
      if (mode === 'month') { viewYear += 1; }
      else {
        viewMonth += 1;
        if (viewMonth > 11) { viewMonth = 0; viewYear += 1; }
      }
      render();
    });

    popup.querySelector('.sp-clear').addEventListener('click', () => {
      if (activeInput) activeInput.value = '';
      hide();
    });

    popup.querySelector('.sp-today').addEventListener('click', () => {
      const now = new Date();
      if (activeInput) activeInput.value = (mode === 'month') ? fmtMonth(now) : fmtDate(now);
      hide();
    });

    return popup;
  }

  function parseValue(val){
    if (!val) return null;
    const parts = val.split('-').map(x => parseInt(x,10));
    if (parts.length === 2 && !Number.isNaN(parts[0]) && !Number.isNaN(parts[1])) {
      return new Date(parts[0], parts[1]-1, 1);
    }
    if (parts.length === 3 && !parts.some(Number.isNaN)) {
      return new Date(parts[0], parts[1]-1, parts[2]);
    }
    return null;
  }

  function positionToInput(input){
    const r = input.getBoundingClientRect();
    const top = window.scrollY + r.bottom + 6;
    const left = window.scrollX + Math.min(r.left, window.innerWidth - 280);
    popup.style.top = top + 'px';
    popup.style.left = left + 'px';
  }

  function render(){
    const title = popup.querySelector('.sp-title');
    const body = popup.querySelector('.sp-body');

    if (mode === 'month') {
      title.textContent = viewYear + T.yearSuffix;
      body.innerHTML = '';
      const grid = document.createElement('div');
      grid.style.cssText = 'display:grid; grid-template-columns:repeat(3,1fr); gap:6px;';
      for (let m=0;m<12;m++){
        const btn = document.createElement('button');
        btn.type='button';
        btn.textContent = T.months[m];
        btn.style.cssText = 'border:1px solid rgba(0,0,0,0.1); background:#fff; border-radius:8px; padding:8px 6px; cursor:pointer;';
        btn.addEventListener('click', ()=>{
          const d = new Date(viewYear, m, 1);
          activeInput.value = fmtMonth(d);
          hide();
        });
        grid.appendChild(btn);
      }
      body.appendChild(grid);
      return;
    }

    // date mode title
    if (LANG === 'en') title.textContent = `${T.months[viewMonth]} ${viewYear}`;
    else {
      const monthSuffix = (LANG === 'ja') ? 'Month' : 'Month';
      title.textContent = `${viewYear}${T.yearSuffix} ${viewMonth+1}${monthSuffix}`;
    }

    const first = new Date(viewYear, viewMonth, 1);
    const startDow = first.getDay();
    const daysInMonth = new Date(viewYear, viewMonth+1, 0).getDate();

    body.innerHTML = '';
    const dow = document.createElement('div');
    dow.style.cssText = 'display:grid; grid-template-columns:repeat(7,1fr); gap:2px; margin-bottom:6px; font-size:12px; color:#667085;';
    T.weekdays.forEach(w=>{
      const d = document.createElement('div');
      d.textContent = w;
      d.style.cssText = 'text-align:center; padding:4px 0;';
      dow.appendChild(d);
    });
    body.appendChild(dow);

    const grid = document.createElement('div');
    grid.style.cssText = 'display:grid; grid-template-columns:repeat(7,1fr); gap:2px;';
    const totalCells = Math.ceil((startDow + daysInMonth)/7)*7;

    for (let i=0;i<totalCells;i++){
      const cell = document.createElement('button');
      cell.type='button';
      cell.style.cssText = 'height:32px; border:none; background:#fff; border-radius:8px; cursor:pointer; font-size:13px;';
      const dayNum = i - startDow + 1;
      if (dayNum < 1 || dayNum > daysInMonth){
        cell.disabled = true;
        cell.textContent = '';
        cell.style.cursor='default';
      } else {
        cell.textContent = String(dayNum);
        cell.addEventListener('click', ()=>{
          const d = new Date(viewYear, viewMonth, dayNum);
          activeInput.value = fmtDate(d);
          hide();
        });
        cell.addEventListener('mouseenter', ()=>{ cell.style.background='#f2f4f7'; });
        cell.addEventListener('mouseleave', ()=>{ cell.style.background='#fff'; });
      }
      grid.appendChild(cell);
    }
    body.appendChild(grid);
  }

  function show(input, newMode){
    mode = newMode;
    activeInput = input;
    ensurePopup();

    const parsed = parseValue(input.value);
    const base = parsed || new Date();

    viewYear = base.getFullYear();
    viewMonth = base.getMonth();

    positionToInput(input);
    popup.style.display = 'block';
    render();
  }

  function hide(){
    if (!popup) return;
    popup.style.display = 'none';
    activeInput = null;
  }

  function attach(selector, m){
    document.querySelectorAll(selector).forEach((input)=>{
      input.addEventListener('focus', ()=> show(input, m));
      input.addEventListener('click', ()=> show(input, m));
      input.addEventListener('keydown', (e)=>{
        if (e.key.length === 1) e.preventDefault();
      });
    });
  }

  attach('input.js-date', 'date');
  attach('input.js-month', 'month');
})();
</script>

