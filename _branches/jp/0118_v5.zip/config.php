<?php
/**
 * TheK-NEXT 설정 파일
 */

// 데이터베이스 설정
define('DB_HOST', 'localhost');
define('DB_USER', 'thek_db_admin');
define('DB_PASS', 'thek_pw_admin!');
define('DB_NAME', 'thek_next_db_branch_jp');
define('DB_CHARSET', 'utf8mb4');

// 세션 설정
define('SESSION_LIFETIME', 3600 * 2); // 2시간
define('SESSION_NAME', 'THEK_SESSION');

// 보안 설정
define('SECURE_COOKIE', false);
define('HTTPONLY_COOKIE', true);

// 언어 설정
define('DEFAULT_LANGUAGE', 'ko');
define('SUPPORTED_LANGUAGES', ['ko', 'ja', 'en']);

// 환경 설정
define('ENVIRONMENT', 'production');
define('DEBUG_MODE', false);

// 에러 로깅
define('ERROR_LOG_PATH', __DIR__ . '/logs/error.log');
define('ENABLE_ERROR_LOG', true);

// 타임존
define('TIMEZONE', 'Asia/Seoul');

// URL 설정
define('BASE_URL', 'http://localhost');

// 보안 키
define('SECRET_KEY', hash('sha256', 'thek-next-secret-' . DB_NAME));

// 로그인 보안
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_ATTEMPT_TIMEOUT', 900);
