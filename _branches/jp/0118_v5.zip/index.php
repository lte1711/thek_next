<?php
// index.php
// 사이트 접속 시 바로 login.php로 이동

header("Location: login.php");
exit;
?>
