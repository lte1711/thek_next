<?php
$page_title = "GM Dashboard";
$content_file = "gm_dashboard_content.php";
include "layout.php";