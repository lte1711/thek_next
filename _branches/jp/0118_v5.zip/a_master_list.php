<?php
session_start();

// Safe i18n initialization (JP branch common)
if (!function_exists('t')) {
    $i18n_path = __DIR__ . '/includes/i18n.php';
    if (file_exists($i18n_path)) {
        require_once $i18n_path;
    } else {
        function t($key, $fallback = null) {
            return $fallback ?? $key;
        }
        function current_lang() {
            return 'ko';
        }
    }
}

// 로그인 여부 확인
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// DB 연결
include 'db_connect.php';

// 회원 조회 쿼리 (등급이 master인 회원만)
$login_user_id = (int)$_SESSION['user_id'];

// ✅ sponsor_id 기준으로 하위 전체(downline) 수집
$ids = [];
$queue = [$login_user_id];

while (!empty($queue)) {
    $current = array_shift($queue);

    $q = mysqli_query($conn, "SELECT id FROM users WHERE sponsor_id=" . (int)$current);
    if (!$q) {
        die("Downline query failed: " . mysqli_error($conn));
    }

    while ($r = mysqli_fetch_assoc($q)) {
        $cid = (int)$r['id'];
        if (!isset($ids[$cid])) {
            $ids[$cid] = true;
            $queue[] = $cid;
        }
    }
}

$downline_ids = array_keys($ids);

// ✅ 하위가 없으면 빈 결과
if (count($downline_ids) === 0) {
    $sql = "SELECT id, username, email, role, phone, country FROM users WHERE 1=0";
} else {
    $in = implode(',', array_map('intval', $downline_ids));

    // ✅ 하위 중 master만
    $sql = "
        SELECT id, username, email, role, phone, country
        FROM users
        WHERE role='master'
          AND id IN ($in)
        ORDER BY id DESC
    ";
}

$result = mysqli_query($conn, $sql);
if (!$result) {
    die('Query failed: ' . mysqli_error($conn));
}

// GET 요청일 때만 레이아웃 출력
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $page_title   = t('master.list.title', 'MASTER Member List');
    $content_file = __DIR__ . "/a_master_list_content.php";
    include "layout.php";
}