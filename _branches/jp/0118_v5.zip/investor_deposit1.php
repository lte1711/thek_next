<?php
// Legacy entry point (kept for backward compatibility)
// 통합된 투자자 입금 화면으로 이동
header('Location: investor_deposit.php');
exit;
