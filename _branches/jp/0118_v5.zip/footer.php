<footer class="site-footer">
  © THEK-NEXT.COM. 모든 권리 보유.
</footer>
