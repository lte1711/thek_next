<?php
// header.php
session_start();
?>
<header class="site-header">
  <h1>THEK-NEXT.COM</h1>
</header>