<?php
require_once 'admin_bootstrap.php';
require_once 'admin_layout.php';
$flash_messages = [];
function flash_add(array &$flash_messages, string $msg): void { $flash_messages[] = $msg; }

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action'])) {
    try {
        if ($_POST['action'] === "create") {
            $user_id        = intval($_POST['user_id']);
            $deposit_amount = floatval($_POST['deposit_amount']);
            $deposit_date   = $_POST['deposit_date'];

            $stmt = $conn->prepare("INSERT INTO admin_deposits_daily (user_id, deposit_amount, deposit_date) VALUES (?, ?, ?)");
            $stmt->bind_param("ids", $user_id, $deposit_amount, $deposit_date);
            $stmt->execute();
            $stmt->close();

            flash_add($flash_messages, "등록 완료");

        } elseif ($_POST['action'] === "update" && isset($_POST['id'])) {
            $id             = intval($_POST['id']);
            $user_id        = intval($_POST['user_id']);
            $deposit_amount = floatval($_POST['deposit_amount']);
            $deposit_date   = $_POST['deposit_date'];

            $stmt = $conn->prepare("UPDATE admin_deposits_daily SET user_id=?, deposit_amount=?, deposit_date=? WHERE id=?");
            $stmt->bind_param("idsi", $user_id, $deposit_amount, $deposit_date, $id);
            $stmt->execute();
            $stmt->close();

            flash_add($flash_messages, "수정 완료 (id={$id})");

        } elseif ($_POST['action'] === "delete" && isset($_POST['id'])) {
            $id = intval($_POST['id']);

            $conn->begin_transaction();
            $stmt = $conn->prepare("DELETE FROM admin_deposits_daily WHERE id=?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $affected = $stmt->affected_rows;
            $stmt->close();
            $conn->commit();

            flash_add($flash_messages, $affected > 0 ? "삭제 완료 (id={$id})" : "삭제 대상 없음 (id={$id})");

        } elseif ($_POST['action'] === "bulk_delete" && !empty($_POST['ids']) && is_array($_POST['ids'])) {
            $ids = array_values(array_filter(array_map('intval', $_POST['ids']), fn($v) => $v > 0));
            if (empty($ids)) {
                flash_add($flash_messages, "일괄삭제: 선택된 ID가 없습니다.");
            } else {
                $conn->begin_transaction();

                $stmt = $conn->prepare("DELETE FROM admin_deposits_daily WHERE id=?");
                $deleted = 0;
                foreach ($ids as $id) {
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $deleted += $stmt->affected_rows > 0 ? 1 : 0;
                }
                $stmt->close();
                $conn->commit();

                $total = count($ids);
                flash_add($flash_messages, "일괄삭제 완료: 요청 {$total}건 / 실제 삭제 {$deleted}건");
            }
        }

    } catch (mysqli_sql_exception $e) {
        try { $conn->rollback(); } catch (Throwable $t) {}
        flash_add($flash_messages, "처리 실패 (DB 오류): " . $e->getMessage());
    }
}

$result = $conn->query("SELECT * FROM admin_deposits_daily ORDER BY id ASC");
?>

?>
<?php admin_render_header('관리자 입금 관리 (admin_deposits_daily)'); ?>
<?php if (!empty($flash_messages)): ?>
    <div class="flash-box">
        <strong>처리 결과</strong>
        <ul>
            <?php foreach ($flash_messages as $m): ?>
                <li><?= htmlspecialchars($m) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<h2>관리자 입금 등록</h2>
<form method="POST">
    <?= csrf_input() ?>

    <input type="hidden" name="action" value="create">
    회원 ID: <input type="number" name="user_id" required><br>
    입금 금액: <input type="text" name="deposit_amount" required><br>
    입금 날짜: <input type="date" name="deposit_date" required><br>
    <button type="submit">등록</button>
</form>

<h2>관리자 입금 목록</h2>
<form method="POST" onsubmit="return confirm('선택한 입금 내역을 정말 삭제하시겠습니까?');">
    <?= csrf_input() ?>

    <input type="hidden" name="action" value="bulk_delete">
    <table>
        <tr>
            <th>선택</th><th>ID</th><th>User ID</th><th>입금 금액</th><th>입금 날짜</th><th>생성일</th><th>수정</th><th>삭제</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><input type="checkbox" name="ids[]" value="<?= htmlspecialchars($row['id']) ?>"></td>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <form method="POST">
    <?= csrf_input() ?>

                <td><input type="number" name="user_id" value="<?= htmlspecialchars($row['user_id']) ?>"></td>
                <td><input type="text" name="deposit_amount" value="<?= htmlspecialchars($row['deposit_amount']) ?>"></td>
                <td><input type="date" name="deposit_date" value="<?= htmlspecialchars($row['deposit_date']) ?>"></td>
                <td><?= htmlspecialchars($row['created_at']) ?></td>
                <td>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($row['id']) ?>">
                    <input type="hidden" name="action" value="update">
                    <button type="submit">수정</button>
                </td>
            </form>
            <form method="POST" onsubmit="return confirm('정말 삭제하시겠습니까?');">
    <?= csrf_input() ?>

                <td>
                    <input type="hidden" name="id" value="<?= htmlspecialchars($row['id']) ?>">
                    <input type="hidden" name="action" value="delete">
                    <button type="submit" style="color:red;">삭제</button>
                </td>
            </form>
        </tr>
        <?php endwhile; ?>
    </table>
    <br>
    <button type="submit" style="color:red;">선택 입금 내역 삭제</button>
</form>
<?php admin_render_footer(); ?>